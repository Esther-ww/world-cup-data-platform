(() => {
const $=jQuery;
if(document.getElementById('course-jquery-panel'))return;
let picking=false,target=null,original=null,enabled=false;
const panel=$('<div id="course-jquery-panel"></div>').css({position:'fixed',top:'90px',right:'24px',width:'300px',padding:'20px',background:'#fff',color:'#222',border:'2px solid #e74a64',borderRadius:'12px',zIndex:2147483647,fontFamily:'sans-serif',fontSize:'16px',boxShadow:'0 8px 30px #0003'});
panel.append('<h2 style="font-size:20px;margin:0 0 12px">笔记标题阅读助手</h2><p id="course-status">先选择页面中的真实笔记标题。</p><button id="course-pick">选择标题</button> <button id="course-toggle" disabled>增强阅读</button> <button id="course-close">移除</button><p style="font-size:12px">只修改所选页面元素的本地样式，刷新即可还原。</p>');
panel.find('button').css({padding:'8px',margin:'4px 0',cursor:'pointer'});$('body').append(panel);
function restore(){if(!target)return;if(original===null)target.removeAttribute('style');else target.setAttribute('style',original);enabled=false;$('#course-toggle').text('增强阅读');}
function pick(e){if(!picking||panel[0].contains(e.target))return;e.preventDefault();e.stopImmediatePropagation();picking=false;restore();target=e.target;original=target.getAttribute('style');$('#course-toggle').prop('disabled',false);$('#course-status').text('已选择：'+(target.textContent||'无文字元素').trim().slice(0,45));}
document.addEventListener('click',pick,true);
$('#course-pick').on('click',()=>{picking=true;$('#course-status').text('请点击左侧或下方的一条笔记标题文字，不要点图片。');});
$('#course-toggle').on('click',function(){
 if(!target||!target.isConnected){$('#course-status').text('所选内容已离开页面，请重新选择。');return;}
 if(enabled){restore();$('#course-status').text('已恢复所选标题的原始样式。');return;}
 // 三条jQuery语句修改真实网页元素，而非实验面板。
 $(target).css('font-size','22px');
 $(target).css('line-height','1.8');
 $(target).css('background-color','#fff0ad');
 enabled=true;$(this).text('恢复原样');$('#course-status').text('已增强所选真实标题：字号22px、行距1.8、浅黄背景。');
});
$('#course-close').on('click',()=>{restore();document.removeEventListener('click',pick,true);panel.remove();});
})();